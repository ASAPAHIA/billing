package com.cg.project.services;

import java.util.HashMap;

import com.cg.project.Dao.ISaleDao;
import com.cg.project.Dao.ISaleDaoImpl;
import com.cg.project.Exceptions.ValidProductCatException;
import com.cg.project.Exceptions.ValidProductCodeException;
import com.cg.project.Exceptions.ValidProductNameException;
import com.cg.project.Exceptions.ValidProductPriceException;
import com.cg.project.Exceptions.ValidQuantityException;
import com.cg.project.beans.Sale;

public class ISaleServicesImpl implements IsaleServices{
private ISaleDao saleDao=new ISaleDaoImpl() ;
	
	@Override
	public HashMap<Integer, Sale> insertSaleDetails(Sale sale) {
		
		return saleDao.insertSaleDetails(sale);
	}

	@Override
	public boolean validateProductCode(int productId) throws ValidProductCodeException {
		if(!(productId>=1001&&productId<=1006)) {
			throw new ValidProductCodeException("enter valid code");
		}
		return true;
	}

	@Override
	public boolean validateQuantity(int qty)throws ValidQuantityException {
		if(!(qty>0&&qty<7)) {
			throw new ValidQuantityException("invalid quantity");
		}
		return true;
	}

	@Override
	public boolean validateProductCat(String prodCat) throws ValidProductCatException {
		if(!(prodCat.equalsIgnoreCase("Electronics")||prodCat.equalsIgnoreCase("Toys"))) {
			throw new ValidProductCatException("not valid category");
		}
		return true;
	}

	@Override
	public boolean validateProductName(String prodName,String prodCat) throws ValidProductNameException {
	if(prodCat.equals("Electronics")) {
		if(!(prodName.equalsIgnoreCase("Tv"))||(!(prodName.equalsIgnoreCase("Smart phone")))||(!(prodName.equalsIgnoreCase("video Game")))){
			throw new ValidProductNameException("not valid name");
		}
	}
	else if(prodCat.equals("Toys")) {
		if(!(prodName.equalsIgnoreCase("Soft toy"))||(!(prodName.equalsIgnoreCase("telescope")))||(!(prodName.equalsIgnoreCase("Barbie Doll")))){
			throw new ValidProductNameException("not valid name");
		}
	}
		return true;
	}

	@Override
	public boolean validateProductPrice(float price) throws ValidProductPriceException {
	if(price<200){
		throw new ValidProductPriceException("not valid price");
	}
		return false;
	}
	
}