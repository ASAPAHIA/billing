package com.cg.project.services;

import java.util.HashMap;

import com.cg.project.Exceptions.ValidProductCatException;
import com.cg.project.Exceptions.ValidProductCodeException;
import com.cg.project.Exceptions.ValidProductNameException;
import com.cg.project.Exceptions.ValidProductPriceException;
import com.cg.project.Exceptions.ValidQuantityException;
import com.cg.project.beans.Sale;

public interface IsaleServices {
public HashMap<Integer, Sale>insertSaleDetails(Sale sale);
public boolean validateProductCode(int productId)throws ValidProductCodeException;
boolean validateQuantity(int qty)throws ValidQuantityException;
public boolean validateProductCat(String prodCat)throws ValidProductCatException;
public boolean validateProductName(String prodName,String prodCat)throws ValidProductNameException;
public boolean validateProductPrice(float price)throws ValidProductPriceException;
}
