package com.cg.project.Util;

import java.util.HashMap;
import java.util.Map;

import com.cg.project.beans.Sale;

public class ServicesUtil {
public static HashMap<Integer,Sale>sales=new HashMap<Integer,Sale>();
public static HashMap<Integer, Sale> getCollection(){
	return sales;
}
public static int getSalesId() {
	int ran=(int)(Math.random()*10000);
	return ran;
}
}
