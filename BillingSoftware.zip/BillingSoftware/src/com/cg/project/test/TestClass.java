package com.cg.project.test;

import java.time.LocalDate;
import java.util.Collection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.project.Exceptions.ValidProductCatException;
import com.cg.project.Exceptions.ValidQuantityException;
import com.cg.project.Util.ServicesUtil;
import com.cg.project.beans.Sale;
import com.cg.project.services.ISaleServicesImpl;
import com.cg.project.services.IsaleServices;




public class TestClass {
	   private static IsaleServices services;
	    @BeforeClass
	    public static void setUpTestEnv() {
	        services=new ISaleServicesImpl();
	    }
	    @Before
	    public void setUpTestData() {
	    	  Sale sale1=new Sale( 1001, "electronics", "tv",LocalDate.now(), 2,2000.0f);
	    	  Sale sale2=new Sale( 1002, "toys", "telescope",LocalDate.now(), 2,2000.0f);
	      }
	    @Test(expected=com.cg.project.Exceptions.ValidProductCodeException.class)
	    public void testForInvalidProductId() throws com.cg.project.Exceptions.ValidProductCodeException {
	        services.validateProductCode(4324);
	    }
	    @Test
	    public void testForValidProductId() throws com.cg.project.Exceptions.ValidProductCodeException {
	        boolean expected=true;
	        boolean actual=services.validateProductCode(1001);
	        Assert.assertEquals(expected, actual);
	    }  
	    @Test(expected=ValidProductCatException.class)
	    public void testForInvalidProductCategory() throws ValidProductCatException {
	        services.validateProductCat("ew");
	        
	    }
	    @Test
	    public void testForValidProductCategory() throws ValidProductCatException{
	    	boolean expected=true;
	    	boolean actual=services.validateProductCat("electronics");
	    	 Assert.assertEquals(expected, actual);
	    }
	    
	    @Test(expected=ValidQuantityException.class)
	    public void testForInvalidProductQuantity() throws ValidQuantityException{
	        services.validateQuantity(10000);
	    }
	    @After
	    public void tearDownTestData() {
	       ServicesUtil.sales.clear();
	    }
	    @AfterClass
	    public static void tearDownTestEnv() {
	        services=null;
	    }
}
