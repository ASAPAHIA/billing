package com.cg.project.Dao;

import java.util.HashMap;

import com.cg.project.Util.ServicesUtil;
import com.cg.project.beans.Sale;

public class ISaleDaoImpl implements ISaleDao{

	@Override
	public HashMap<Integer, Sale> insertSaleDetails(Sale sale) {
		 ServicesUtil.sales.put(sale.getProdCode(),sale);
		 return ServicesUtil.sales;
	}

}
