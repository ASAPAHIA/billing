package com.cg.project.Dao;

import java.util.HashMap;

import com.cg.project.beans.Sale;

public interface ISaleDao {
public HashMap<Integer, Sale> insertSaleDetails(Sale sale);
}
