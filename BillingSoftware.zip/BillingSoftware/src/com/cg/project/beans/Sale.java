package com.cg.project.beans;

import java.time.LocalDate;

public class Sale {
private int saleId;
private int prodCode;
private String productName;
private String category;
private LocalDate SaleDate;
private int quantity;
private Float lineTotal;
private Float prodPrice;

public Sale() {

}

public Sale(int prodCode, String productName, String category, LocalDate saleDate, int quantity,
		Float prodPrice) {
	super();
	this.prodCode = prodCode;
	this.productName = productName;
	this.category = category;
	SaleDate = saleDate;
	this.quantity = quantity;
	this.prodPrice = prodPrice;
}

public Sale(int saleId, int prodCode, String productName, String category, LocalDate saleDate, int quantity,
		Float lineTotal, Float prodPrice) {
	super();
	this.saleId = saleId;
	this.prodCode = prodCode;
	this.productName = productName;
	this.category = category;
	SaleDate = saleDate;
	this.quantity = quantity;
	this.lineTotal = lineTotal;
	this.prodPrice = prodPrice;
}

public int getSaleId() {
	return saleId;
}

public void setSaleId(int saleId) {
	this.saleId = saleId;
}

public int getProdCode() {
	return prodCode;
}

public void setProdCode(int prodCode) {
	this.prodCode = prodCode;
}

public String getProductName() {
	return productName;
}

public void setProductName(String productName) {
	this.productName = productName;
}

public String getCategory() {
	return category;
}

public void setCategory(String category) {
	this.category = category;
}

public LocalDate getSaleDate() {
	return SaleDate;
}

public void setSaleDate(LocalDate saleDate) {
	SaleDate = saleDate;
}

public int getQuantity() {
	return quantity;
}

public void setQuantity(int quantity) {
	this.quantity = quantity;
}

public Float getLineTotal() {
	return lineTotal;
}

public void setLineTotal(Float lineTotal) {
	this.lineTotal = lineTotal;
}

public Float getProdPrice() {
	return prodPrice;
}

public void setProdPrice(Float prodPrice) {
	this.prodPrice = prodPrice;
}

@Override
public String toString() {
	return "Sale [saleId=" + saleId + ", prodCode=" + prodCode + ", productName=" + productName + ", category="
			+ category + ", SaleDate=" + SaleDate + ", quantity=" + quantity + ", lineTotal=" + lineTotal
			+ ", prodPrice=" + prodPrice + "]";
}

}