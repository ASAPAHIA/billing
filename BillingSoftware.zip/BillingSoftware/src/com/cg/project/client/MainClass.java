package com.cg.project.client;

import java.time.LocalDate;
import java.util.Scanner;

import com.cg.project.Exceptions.ValidProductCatException;
import com.cg.project.Exceptions.ValidProductNameException;
import com.cg.project.Exceptions.ValidProductPriceException;
import com.cg.project.Exceptions.ValidQuantityException;
import com.cg.project.Util.ServicesUtil;
import com.cg.project.beans.Sale;
import com.cg.project.services.ISaleServicesImpl;
import com.cg.project.services.IsaleServices;


public class MainClass {
public static void main(String args[]) {
	IsaleServices services=new ISaleServicesImpl();
	Scanner sc=new Scanner(System.in);
	   LocalDate currDate=LocalDate.now();
	
	System.out.println("enter productCode");
	int procode=sc.nextInt();
	
	System.out.println("enter quantity");
	int  quan=sc.nextInt();
	
	System.out.println("enter category");
	String cat=sc.next();
	
	System.out.println("enter prod name");
	String proName=sc.next();
	
	System.out.println("enter price");
	Float price=sc.nextFloat();
	
	Float lineTotal=price*quan ;

	
	Sale sale=new Sale(ServicesUtil.getSalesId(), procode, proName,cat,currDate, quan, lineTotal,price);
	
    try {
    	services.validateProductCat(cat);
    	services.validateProductCode(procode);
    	services.validateProductName(proName, cat);
    	services.validateProductPrice(price);
        services.insertSaleDetails(sale);
        
        System.out.println("Bill details =");
        System.out.println("ID : "+sale.getSaleId());
        System.out.println("product code:"+procode);
        System.out.println("Product Category : "+cat);
        System.out.println("Product Description : "+proName);
        System.out.println("Product Price : "+price);
        System.out.println("Quantity: "+quan);
        System.out.println("Purchase Date:"+currDate);
        System.out.println("Line Total(Rs): "+lineTotal);
        
 }
         catch(ValidProductCatException e) {
             System.out.println("Category should be electronics or toys"); }
         catch(ValidProductNameException e) {
             System.out.println("not valid name"); }
         catch(ValidQuantityException e) {
             System.out.println("Quantity should be greater than 0 and less than 5"); }
         catch(com.cg.project.Exceptions.ValidProductCodeException e) {
             System.out.println("Product code not valid");}
             catch(ValidProductPriceException e) {
            	 System.out.println("price should be greater than 200");
             }
         }
     }



